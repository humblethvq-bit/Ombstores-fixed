// Central place for business details.
// Update phone numbers, address and hours here — every component reads from this file.
export const siteConfig = {
  name: "OMBStores",
  tagline: "Your Trusted Phone & Accessories Store",
  description:
    "Professional phone repairs, genuine accessories, smartphones, tablets, and laptops at affordable prices in Kasoa Danchira, Ghana.",
  location: {
    line1: "Kasoa Danchira",
    line2: "Mataheko Junction",
    city: "Kasoa, Central Region, Ghana",
    mapEmbedUrl:
      "https://www.google.com/maps?q=Kasoa+Danchira+Mataheko+Junction+Ghana&output=embed",
    mapLinkUrl: "https://www.google.com/maps/search/?api=1&query=Kasoa+Danchira+Mataheko+Junction+Ghana",
  },
  phone: {
    display: "+233 54 457 0533",
    // Used for tel: links and click-to-call buttons.
    tel: "+233544570533",
  },
  whatsapp: {
    display: "+233 20 139 0997",
    // Digits only, country code first, no +/spaces — required for wa.me links.
    number: "233201390997",
    defaultMessage: "Hello OMBStores! I'd like to ask about",
  },
  email: "hello@ombstores.com",
  socials: {
    instagram: "https://instagram.com/ombstores",
    facebook: "https://facebook.com/ombstores",
    tiktok: "https://tiktok.com/@ombstores",
  },
  hours: [
    { day: "Monday – Friday", time: "8:00 AM – 8:00 PM" },
    { day: "Saturday", time: "8:00 AM – 8:00 PM" },
    { day: "Sunday", time: "12:00 PM – 6:00 PM" },
  ],
};

export function buildWhatsAppLink(context) {
  const base = `https://wa.me/${siteConfig.whatsapp.number}`;
  const text = context
    ? `${siteConfig.whatsapp.defaultMessage} ${context}`
    : siteConfig.whatsapp.defaultMessage;
  return `${base}?text=${encodeURIComponent(text)}`;
}
