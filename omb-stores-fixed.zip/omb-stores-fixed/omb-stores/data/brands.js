// Brands carried in-store. `initial` renders as a text-mark placeholder logo —
// swap for real SVG/PNG brand logos in /public/images/brands/ later.
export const brands = [
  { name: "Apple", initial: "" },
  { name: "Samsung", initial: "S" },
  { name: "Tecno", initial: "T" },
  { name: "Infinix", initial: "I" },
  { name: "itel", initial: "i" },
  { name: "Xiaomi", initial: "M" },
  { name: "Oppo", initial: "O" },
  { name: "Vivo", initial: "V" },
];
