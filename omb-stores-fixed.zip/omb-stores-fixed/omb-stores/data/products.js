// Product catalogue — placeholder data + placeholder images.
// Replace `image` with real product photography and update price/stock as needed.
// Prices are in Ghana Cedis (GH₵).

export const categories = [
  "All",
  "Smartphones",
  "Phone Cases",
  "Screen Protectors",
  "Chargers",
  "Cables",
  "Bluetooth Earbuds",
  "Headsets",
  "Smart Watches",
  "Power Banks",
  "Laptop Accessories",
];

const img = (seed) => `https://picsum.photos/seed/${seed}/600/600`;

export const products = [
  { id: "p1", name: "Galaxy-Series Smartphone 128GB", category: "Smartphones", brand: "Samsung", price: 3200, oldPrice: 3500, rating: 4.8, image: img("omb-phone-1"), badge: "New" },
  { id: "p2", name: "iStyle Pro Smartphone 256GB", category: "Smartphones", brand: "Apple", price: 6800, rating: 4.9, image: img("omb-phone-2"), badge: "Best Seller" },
  { id: "p3", name: "Spark-Series Smartphone 64GB", category: "Smartphones", brand: "Tecno", price: 1450, rating: 4.5, image: img("omb-phone-3") },
  { id: "p4", name: "Hot-Series Smartphone 128GB", category: "Smartphones", brand: "Infinix", price: 1650, rating: 4.6, image: img("omb-phone-4") },
  { id: "p5", name: "Redmi-Style Smartphone 128GB", category: "Smartphones", brand: "Xiaomi", price: 2100, rating: 4.7, image: img("omb-phone-5") },

  { id: "c1", name: "Shockproof Silicone Case", category: "Phone Cases", brand: "OMBStores", price: 60, rating: 4.6, image: img("omb-case-1") },
  { id: "c2", name: "Clear Slim-Fit Case", category: "Phone Cases", brand: "OMBStores", price: 45, rating: 4.4, image: img("omb-case-2") },
  { id: "c3", name: "Leather Wallet Case", category: "Phone Cases", brand: "OMBStores", price: 90, rating: 4.7, image: img("omb-case-3"), badge: "Popular" },

  { id: "s1", name: "9H Tempered Glass Protector", category: "Screen Protectors", brand: "OMBStores", price: 35, rating: 4.5, image: img("omb-glass-1") },
  { id: "s2", name: "Privacy Screen Protector", category: "Screen Protectors", brand: "OMBStores", price: 55, rating: 4.4, image: img("omb-glass-2") },

  { id: "ch1", name: "20W Fast Wall Charger", category: "Chargers", brand: "Apple", price: 120, rating: 4.8, image: img("omb-charger-1") },
  { id: "ch2", name: "65W GaN Dual-Port Charger", category: "Chargers", brand: "Xiaomi", price: 180, rating: 4.7, image: img("omb-charger-2"), badge: "New" },
  { id: "ch3", name: "Car Fast Charger Dual-USB", category: "Chargers", brand: "OMBStores", price: 90, rating: 4.3, image: img("omb-charger-3") },

  { id: "cb1", name: "USB-C to USB-C Cable 1m", category: "Cables", brand: "OMBStores", price: 40, rating: 4.5, image: img("omb-cable-1") },
  { id: "cb2", name: "Lightning Cable 1m", category: "Cables", brand: "Apple", price: 70, rating: 4.7, image: img("omb-cable-2") },
  { id: "cb3", name: "Braided USB-A Cable 2m", category: "Cables", brand: "OMBStores", price: 50, rating: 4.4, image: img("omb-cable-3") },

  { id: "e1", name: "TrueSound Bluetooth Earbuds", category: "Bluetooth Earbuds", brand: "OMBStores", price: 250, rating: 4.6, image: img("omb-earbuds-1"), badge: "Best Seller" },
  { id: "e2", name: "Noise-Cancelling Earbuds Pro", category: "Bluetooth Earbuds", brand: "Xiaomi", price: 380, rating: 4.7, image: img("omb-earbuds-2") },

  { id: "h1", name: "Over-Ear Wireless Headset", category: "Headsets", brand: "OMBStores", price: 320, rating: 4.5, image: img("omb-headset-1") },
  { id: "h2", name: "Gaming Headset with Mic", category: "Headsets", brand: "OMBStores", price: 280, rating: 4.4, image: img("omb-headset-2") },

  { id: "w1", name: "FitTrack Smart Watch", category: "Smart Watches", brand: "OMBStores", price: 420, rating: 4.6, image: img("omb-watch-1"), badge: "New" },
  { id: "w2", name: "Series Pro Smart Watch", category: "Smart Watches", brand: "Apple", price: 1600, rating: 4.8, image: img("omb-watch-2") },

  { id: "pb1", name: "10,000mAh Power Bank", category: "Power Banks", brand: "OMBStores", price: 150, rating: 4.5, image: img("omb-powerbank-1") },
  { id: "pb2", name: "20,000mAh Fast-Charge Power Bank", category: "Power Banks", brand: "Xiaomi", price: 260, rating: 4.7, image: img("omb-powerbank-2") },

  { id: "l1", name: "Universal Laptop Charger", category: "Laptop Accessories", brand: "OMBStores", price: 220, rating: 4.4, image: img("omb-laptop-1") },
  { id: "l2", name: "Laptop Sleeve 14-inch", category: "Laptop Accessories", brand: "OMBStores", price: 130, rating: 4.5, image: img("omb-laptop-2") },
  { id: "l3", name: "USB-C Multiport Hub", category: "Laptop Accessories", brand: "OMBStores", price: 190, rating: 4.6, image: img("omb-laptop-3"), badge: "New" },
];
