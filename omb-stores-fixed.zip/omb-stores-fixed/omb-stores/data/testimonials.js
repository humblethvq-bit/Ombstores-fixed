export const testimonials = [
  {
    name: "Ama Owusu",
    location: "Kasoa",
    rating: 5,
    quote:
      "My screen was replaced in under an hour and it looks brand new. Friendly staff and fair prices.",
  },
  {
    name: "Kwabena Mensah",
    location: "Bawjiase",
    rating: 5,
    quote:
      "They recovered photos I thought were gone forever after my phone fell in water. Truly grateful.",
  },
  {
    name: "Linda Boateng",
    location: "Kasoa Danchira",
    rating: 5,
    quote:
      "Bought my earbuds and a power bank here — genuine products and the prices beat everywhere else nearby.",
  },
  {
    name: "Yaw Darko",
    location: "Mataheko",
    rating: 4,
    quote:
      "Fast charging port repair on my laptop. Explained the issue clearly before starting the work.",
  },
];
