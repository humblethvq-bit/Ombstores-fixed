# OMBStores — Website

A modern, mobile-first Next.js website for OMBStores, a phone repair and
accessories store in Kasoa Danchira (Mataheko Junction), Ghana.

## Stack

- **Next.js 14** (App Router) + **React 18**
- **Tailwind CSS** — brand tokens in `tailwind.config.js` match the official
  OMB logo palette (`#007BFF` blue / `#0B0F1A` navy / white)
- Plain `.jsx` — no TypeScript required
- No external UI/icon libraries — icons are inline SVGs in `components/Icons.jsx`

## Getting started

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

```bash
npm run build
npm run start
```

for a production build.

## Project structure

```
app/                 Routes (App Router) — one folder per page
  page.jsx            Home
  shop/                Shop (product catalogue + filtering)
  repair-services/     Repair Services + booking form
  about/               About
  contact/             Contact
  layout.jsx           Root layout: fonts, metadata, favicon, global chrome
  sitemap.js           Auto-generated sitemap.xml
components/          Reusable UI components
context/             React context: theme, cart, wishlist (persisted to localStorage)
data/                 Editable content: products, services, brands, testimonials, site info
public/images/logo/   Official OMB logo assets (favicon set + icon marks)
```

## Editing content

- **Business info** (phone, WhatsApp, email, address, hours): `data/siteConfig.js`
- **Products**: `data/products.js` — add/edit items, prices are in GH₵
- **Repair services**: `data/services.js`
- **Brands strip**: `data/brands.js`
- **Testimonials**: `data/testimonials.js`

## Logo & branding

The header, footer, favicon, browser tab icon, homescreen icon, and loading
screen all use the real OMB logo mark exported to
`public/images/logo/`:

- `omb-icon-color.png` — blue/black mark, transparent background, for light surfaces
- `omb-icon-white.png` — white mark, transparent background, for dark surfaces (hero, footer, loading screen)
- `favicon-*.png` / `favicon.ico` — generated favicon set

To swap in an updated logo later, replace these files (keeping the same
names/transparent backgrounds) and regenerate the favicon sizes if needed —
no component code changes required.

## Images

Product photos currently use placeholder images (`picsum.photos`) so the
layout can be reviewed immediately. Replace `image` values in
`data/products.js` with real product photography — either local files in
`public/images/products/` or a hosted CDN. If you host images on a new
domain, add it to `images.remotePatterns` in `next.config.js`.

## Features included

- Dark / light mode (persisted)
- Product search + category filtering + sort
- Shopping cart (persisted, WhatsApp checkout handoff)
- Wishlist (persisted)
- Repair booking form (WhatsApp handoff)
- Contact form (WhatsApp handoff)
- Floating WhatsApp button
- Newsletter signup (front-end only — wire to your email provider)
- Responsive, accessible (visible focus states, semantic labels, reduced-motion aware)
- SEO metadata, sitemap.xml, robots.txt
- Scroll-reveal animations (`components/Reveal.jsx`), trust stats band, gradient
  newsletter CTA band, and a custom branded 404 page

## Payments (Mobile Money / card) — future integration

Checkout currently hands off to WhatsApp so orders can be confirmed and paid
in person or via mobile money manually. When you're ready to accept payments
online:

1. Pick a Ghanaian payment provider (e.g. Paystack or Hubtel) that supports
   Mobile Money and card.
2. Add a `/app/api/checkout/route.js` API route that creates a payment
   session using the cart contents from `context/CartContext.jsx`.
3. Replace the "Checkout on WhatsApp" button in `components/CartDrawer.jsx`
   with a call to that route, then redirect to the provider's payment page.

The cart/subtotal logic already needed for this is in place in
`context/CartContext.jsx`.

## Deployment

Deploy-ready for Vercel (recommended for Next.js), Netlify, or any Node
host:

```bash
npm run build
```

then follow your host's Next.js deployment instructions. No environment
variables are required for the current feature set.
