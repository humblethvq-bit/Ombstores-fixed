/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
    "./context/**/*.{js,jsx}",
    "./data/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      spacing: {
        "4.5": "1.125rem",
      },
      colors: {
        // OMBStores brand tokens — derived from the official OMB logo palette
        // (#007BFF blue / #0B0F1A ink / #FFFFFF white)
        royal: {
          50: "#EAF3FF",
          100: "#D6E9FF",
          200: "#ADD2FF",
          300: "#7DB6FF",
          400: "#4098FF",
          500: "#1E88FF",
          600: "#007BFF", // primary brand blue — from logo
          700: "#0A63CC",
          800: "#0E4C99", // deep royal — headers, dark surfaces
          900: "#0B0F1A", // logo ink — near-black navy
          950: "#05070D",
        },
        ink: {
          900: "#0B0F1A", // exact logo ink
          700: "#20242E",
          500: "#5B6472",
        },
        mist: "#F4F7FC",
      },
      fontFamily: {
        display: ["var(--font-sora)", "system-ui", "sans-serif"],
        body: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
      borderRadius: {
        xl: "1rem",
        "2xl": "1.5rem",
        "3xl": "2rem",
      },
      boxShadow: {
        card: "0 4px 24px -4px rgba(20, 43, 140, 0.10)",
        "card-hover": "0 12px 40px -8px rgba(20, 43, 140, 0.22)",
        glow: "0 0 0 1px rgba(37, 64, 224, 0.15), 0 20px 60px -10px rgba(37, 64, 224, 0.45)",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-14px)" },
        },
        floatSlow: {
          "0%, 100%": { transform: "translateY(0px) rotate(0deg)" },
          "50%": { transform: "translateY(-10px) rotate(1deg)" },
        },
        pulseRing: {
          "0%": { transform: "scale(0.9)", opacity: "0.6" },
          "70%": { transform: "scale(1.4)", opacity: "0" },
          "100%": { transform: "scale(1.4)", opacity: "0" },
        },
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        logoPulse: {
          "0%, 100%": { transform: "scale(1)", opacity: "1" },
          "50%": { transform: "scale(1.06)", opacity: "0.85" },
        },
        loaderOut: {
          "0%": { opacity: "1", visibility: "visible" },
          "100%": { opacity: "0", visibility: "hidden" },
        },
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        floatSlow: "floatSlow 8s ease-in-out infinite",
        pulseRing: "pulseRing 2.4s cubic-bezier(0.4,0,0.6,1) infinite",
        fadeUp: "fadeUp 0.7s ease-out both",
        marquee: "marquee 28s linear infinite",
        logoPulse: "logoPulse 1.6s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
