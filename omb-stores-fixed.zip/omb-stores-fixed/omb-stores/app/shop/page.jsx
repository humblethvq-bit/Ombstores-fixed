import { Suspense } from "react";
import PageHero from "@/components/PageHero";
import ShopExperience from "@/components/ShopExperience";

export const metadata = {
  title: "Shop",
  description:
    "Browse genuine smartphones, cases, chargers, cables, earbuds, smart watches and more at OMBStores, Kasoa Danchira.",
};

export default function ShopPage() {
  return (
    <>
      <PageHero
        eyebrow="Shop OMBStores"
        title="Genuine Phones & Accessories"
        description="Smartphones, cases, screen protectors, chargers, earbuds, smart watches and more — all authentic, all affordable."
      />
      <section className="section-y">
        <div className="container-page">
          <Suspense fallback={<p className="text-sm text-ink-500">Loading products…</p>}>
            <ShopExperience />
          </Suspense>
        </div>
      </section>
    </>
  );
}
