import PageHero from "@/components/PageHero";
import SectionHeading from "@/components/SectionHeading";
import ServicesGrid from "@/components/ServicesGrid";
import RepairBookingForm from "@/components/RepairBookingForm";
import { IconWhatsApp } from "@/components/Icons";
import { buildWhatsAppLink } from "@/data/siteConfig";

export const metadata = {
  title: "Repair Services",
  description:
    "Screen replacement, battery replacement, charging port repair, data recovery, FRP unlock and more at OMBStores, Kasoa Danchira.",
};

export default function RepairServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Repair Services"
        title="Fast, Reliable Device Repairs"
        description="Certified technicians, genuine parts, and honest pricing — for phones, tablets and laptops."
      />

      <section className="section-y">
        <div className="container-page">
          <SectionHeading
            eyebrow="What We Fix"
            title="A repair for every issue"
            description="Tap a service to jump to the booking form, or chat with us on WhatsApp for a quick diagnosis."
          />
          <div className="mt-10">
            <ServicesGrid />
          </div>
        </div>
      </section>

      <section className="section-y bg-mist dark:bg-ink-900/60">
        <div className="container-page grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:items-start">
          <div>
            <span className="eyebrow">How It Works</span>
            <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">Simple, transparent process</h2>
            <ol className="mt-6 flex flex-col gap-5">
              {[
                { title: "Book or walk in", text: "Fill the form, WhatsApp us, or visit us at Mataheko Junction." },
                { title: "Free diagnosis", text: "We inspect your device and confirm the issue and price upfront." },
                { title: "We repair", text: "Most repairs are completed same-day, often within the hour." },
                { title: "Pick up & go", text: "Collect your device, tested and working — with warranty on select repairs." },
              ].map((step, i) => (
                <li key={step.title} className="flex gap-4">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-royal-600 text-sm font-bold text-white">
                    {i + 1}
                  </span>
                  <div>
                    <p className="font-display text-base font-bold">{step.title}</p>
                    <p className="mt-1 text-sm text-ink-500">{step.text}</p>
                  </div>
                </li>
              ))}
            </ol>

            <a href={buildWhatsAppLink("a repair")} target="_blank" rel="noopener noreferrer" className="btn-whatsapp mt-8">
              <IconWhatsApp className="h-4 w-4" />
              Ask a Question on WhatsApp
            </a>
          </div>

          <RepairBookingForm />
        </div>
      </section>
    </>
  );
}
