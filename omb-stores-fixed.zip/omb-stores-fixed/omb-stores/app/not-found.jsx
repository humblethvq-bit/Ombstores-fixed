import Link from "next/link";
import Image from "next/image";
import { buildWhatsAppLink } from "@/data/siteConfig";
import { IconWhatsApp } from "@/components/Icons";

export default function NotFound() {
  return (
    <section className="relative overflow-hidden bg-ink-900 bg-grid-pattern">
      <div className="pointer-events-none absolute -left-40 -top-40 h-[28rem] w-[28rem] rounded-full bg-royal-500/25 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -right-32 h-[28rem] w-[28rem] rounded-full bg-royal-400/15 blur-3xl" />

      <div className="container-page relative flex min-h-[70vh] flex-col items-center justify-center py-24 text-center">
        <div className="relative h-16 w-16 opacity-90">
          <Image src="/images/logo/omb-icon-white.png" alt="OMBStores" fill sizes="64px" className="object-contain" />
        </div>
        <p className="mt-8 font-display text-7xl font-extrabold text-white sm:text-8xl">404</p>
        <h1 className="mt-4 font-display text-2xl font-bold text-white sm:text-3xl">
          This page wandered off
        </h1>
        <p className="mt-3 max-w-md text-royal-100/80">
          The page you&apos;re looking for doesn&apos;t exist or may have moved. Let&apos;s get you back on track.
        </p>
        <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row">
          <Link href="/" className="btn-primary !bg-white !text-royal-700 hover:!bg-royal-50">
            Back to Home
          </Link>
          <Link href="/shop" className="btn-secondary border-white/50 bg-white/5 text-white hover:bg-white hover:text-royal-700">
            Browse Shop
          </Link>
          <a href={buildWhatsAppLink()} target="_blank" rel="noopener noreferrer" className="btn-whatsapp">
            <IconWhatsApp className="h-4 w-4" />
            Chat on WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
