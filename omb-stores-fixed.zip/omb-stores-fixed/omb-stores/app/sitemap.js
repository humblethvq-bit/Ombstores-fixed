export default function sitemap() {
  const base = "https://www.ombstores.com";
  const routes = ["", "/shop", "/repair-services", "/about", "/contact"];

  return routes.map((route) => ({
    url: `${base}${route}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: route === "" ? 1 : 0.8,
  }));
}
