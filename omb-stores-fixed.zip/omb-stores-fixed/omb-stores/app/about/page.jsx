import PageHero from "@/components/PageHero";
import SectionHeading from "@/components/SectionHeading";
import WhyChooseUs from "@/components/WhyChooseUs";
import BrandStrip from "@/components/BrandStrip";
import Testimonials from "@/components/Testimonials";
import Image from "next/image";

export const metadata = {
  title: "About Us",
  description:
    "OMBStores is a trusted phone repair and accessories store based in Kasoa Danchira, Mataheko Junction, Ghana.",
};

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About OMBStores"
        title="Repair. Buy. Upgrade. Protect."
        description="Everything you need for your phone, tablet or laptop — all in one place, right here in Kasoa Danchira."
      />

      <section className="section-y">
        <div className="container-page grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <span className="eyebrow">Our Story</span>
            <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">
              Built for the Kasoa community
            </h2>
            <p className="mt-5 text-base leading-relaxed text-ink-500">
              OMBStores started at Mataheko Junction with a simple goal: give people in Kasoa
              Danchira a place they can trust with their devices — whether that&apos;s a cracked
              screen that needs fixing today, or a new phone that needs to last for years.
            </p>
            <p className="mt-4 text-base leading-relaxed text-ink-500">
              Every repair is handled by a certified technician using genuine parts, and every
              product on our shelves is authentic. No shortcuts, no guesswork — just honest
              service at a fair price.
            </p>
          </div>
          <div className="relative mx-auto flex h-64 w-64 items-center justify-center rounded-3xl bg-ink-900 shadow-glow sm:h-80 sm:w-80">
            <div className="relative h-40 w-40 sm:h-52 sm:w-52">
              <Image
                src="/images/logo/omb-icon-white.png"
                alt="OMB Phone & Accessories logo"
                fill
                sizes="208px"
                className="object-contain"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="section-y bg-mist dark:bg-ink-900/60">
        <div className="container-page">
          <SectionHeading eyebrow="Our Mission" title="Quality, trust and reliability" center />
          <div className="mx-auto mt-10 grid max-w-4xl gap-5 sm:grid-cols-3">
            {[
              { title: "Quality", text: "Genuine parts and products, every time — no imitations." },
              { title: "Trust", text: "Transparent pricing and honest diagnoses you can rely on." },
              { title: "Reliability", text: "Fast turnarounds and consistent service you can count on." },
            ].map((v) => (
              <div key={v.title} className="card p-6 text-center">
                <h3 className="font-display text-lg font-bold text-royal-600 dark:text-royal-300">{v.title}</h3>
                <p className="mt-2 text-sm text-ink-500">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <WhyChooseUs />
      <BrandStrip />
      <Testimonials />
    </>
  );
}
