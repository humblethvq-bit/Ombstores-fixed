import PageHero from "@/components/PageHero";
import ContactSection from "@/components/ContactSection";
import ContactForm from "@/components/ContactForm";

export const metadata = {
  title: "Contact Us",
  description:
    "Visit OMBStores at Kasoa Danchira, Mataheko Junction, or reach us by phone, WhatsApp or email.",
};

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact Us"
        title="We're Here to Help"
        description="Questions about a repair, a product, or just want directions? Reach out any way that suits you."
      />
      <ContactSection />
      <section className="section-y">
        <div className="container-page">
          <ContactForm />
        </div>
      </section>
    </>
  );
}
