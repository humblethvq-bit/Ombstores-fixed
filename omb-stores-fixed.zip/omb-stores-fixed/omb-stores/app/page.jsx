import Link from "next/link";
import Hero from "@/components/Hero";
import SectionHeading from "@/components/SectionHeading";
import ServicesGrid from "@/components/ServicesGrid";
import BrandStrip from "@/components/BrandStrip";
import StatsBand from "@/components/StatsBand";
import WhyChooseUs from "@/components/WhyChooseUs";
import Testimonials from "@/components/Testimonials";
import NewsletterCTA from "@/components/NewsletterCTA";
import ContactSection from "@/components/ContactSection";
import ProductCard from "@/components/ProductCard";
import Reveal from "@/components/Reveal";
import { products, categories } from "@/data/products";

export default function HomePage() {
  const featured = products.slice(0, 10);
  const productCategories = categories.filter((c) => c !== "All");

  return (
    <>
      <Hero />
      <BrandStrip />
      <StatsBand />

      {/* Repair services */}
      <section className="section-y">
        <div className="container-page">
          <Reveal>
            <div className="flex flex-wrap items-end justify-between gap-6">
              <SectionHeading
                eyebrow="Repair Services"
                title="Expert repairs for every device"
                description="From cracked screens to stubborn software issues — our certified technicians handle it all."
              />
              <Link href="/repair-services" className="btn-secondary shrink-0">
                View All Services
              </Link>
            </div>
          </Reveal>
          <div className="mt-10">
            <ServicesGrid limit={5} />
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="section-y bg-mist dark:bg-ink-900/60">
        <div className="container-page">
          <Reveal>
            <div className="flex flex-wrap items-end justify-between gap-6">
              <SectionHeading
                eyebrow="Shop"
                title="Genuine phones & accessories"
                description="Smartphones, cases, chargers, earbuds and more — all in stock, all authentic."
              />
              <Link href="/shop" className="btn-secondary shrink-0">
                Shop All Products
              </Link>
            </div>
          </Reveal>

          <div className="no-scrollbar mt-8 flex gap-2 overflow-x-auto pb-1">
            {productCategories.map((c) => (
              <Link
                key={c}
                href={`/shop?search=${encodeURIComponent(c)}`}
                className="shrink-0 rounded-full border border-royal-100 bg-white px-4 py-2 text-xs font-semibold text-ink-700 transition-colors hover:border-royal-300 hover:text-royal-600 dark:border-white/10 dark:bg-ink-700 dark:text-white/80"
              >
                {c}
              </Link>
            ))}
          </div>

          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {featured.map((product, i) => (
              <Reveal key={product.id} delay={(i % 5) * 60} className="h-full">
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <WhyChooseUs />
      <Testimonials />
      <NewsletterCTA />
      <ContactSection />
    </>
  );
}
