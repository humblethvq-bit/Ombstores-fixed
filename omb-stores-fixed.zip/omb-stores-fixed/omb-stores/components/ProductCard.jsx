"use client";

import Image from "next/image";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { IconHeart, IconStar, IconCart } from "@/components/Icons";

export default function ProductCard({ product }) {
  const { addItem } = useCart();
  const { toggleItem, isWishlisted } = useWishlist();
  const wishlisted = isWishlisted(product.id);

  return (
    <div className="card group flex h-full flex-col overflow-hidden">
      <div className="relative aspect-square overflow-hidden bg-mist dark:bg-white/5">
        <Image
          src={product.image}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {product.badge && (
          <span className="absolute left-3 top-3 rounded-full bg-royal-600 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-white">
            {product.badge}
          </span>
        )}
        <button
          type="button"
          onClick={() => toggleItem(product)}
          aria-label={wishlisted ? "Remove from wishlist" : "Add to wishlist"}
          aria-pressed={wishlisted}
          className={`absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full backdrop-blur-md transition-colors ${
            wishlisted ? "bg-royal-600 text-white" : "bg-white/80 text-ink-700 hover:bg-white"
          }`}
        >
          <IconHeart className="h-4.5 w-4.5" fill={wishlisted ? "currentColor" : "none"} />
        </button>
      </div>

      <div className="flex flex-1 flex-col p-4">
        <span className="text-xs font-semibold uppercase tracking-wide text-royal-500">{product.brand}</span>
        <h3 className="mt-1 line-clamp-2 font-display text-sm font-bold leading-snug">{product.name}</h3>

        <div className="mt-1.5 flex items-center gap-1 text-amber-400" aria-label={`Rated ${product.rating} out of 5`}>
          {Array.from({ length: 5 }).map((_, i) => (
            <IconStar key={i} className={`h-3 w-3 ${i < Math.round(product.rating) ? "opacity-100" : "opacity-20"}`} />
          ))}
          <span className="ml-1 text-xs font-semibold text-ink-500">{product.rating}</span>
        </div>

        <div className="mt-3 flex items-center gap-2">
          <span className="font-display text-lg font-bold text-royal-700 dark:text-royal-300">
            GH₵ {product.price.toLocaleString()}
          </span>
          {product.oldPrice && (
            <span className="text-sm text-ink-500 line-through">GH₵ {product.oldPrice.toLocaleString()}</span>
          )}
        </div>

        <button
          type="button"
          onClick={() => addItem(product)}
          className="btn-primary mt-4 w-full !py-2.5 text-xs"
        >
          <IconCart className="h-4 w-4" />
          Add to Cart
        </button>
      </div>
    </div>
  );
}
