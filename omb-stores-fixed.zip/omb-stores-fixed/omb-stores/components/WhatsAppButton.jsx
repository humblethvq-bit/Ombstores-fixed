import { buildWhatsAppLink } from "@/data/siteConfig";
import { IconWhatsApp } from "@/components/Icons";

export default function WhatsAppButton() {
  return (
    <a
      href={buildWhatsAppLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with OMBStores on WhatsApp"
      className="group fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-card-hover transition-transform duration-300 hover:scale-110 active:scale-95 sm:bottom-8 sm:right-8"
    >
      <span className="absolute inline-flex h-full w-full animate-pulseRing rounded-full bg-[#25D366] reduce-motion-safe" />
      <IconWhatsApp className="relative h-7 w-7" />
    </a>
  );
}
