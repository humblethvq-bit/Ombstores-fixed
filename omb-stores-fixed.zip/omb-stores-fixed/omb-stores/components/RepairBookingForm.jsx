"use client";

import { useState } from "react";
import { services } from "@/data/services";
import { buildWhatsAppLink } from "@/data/siteConfig";

const initialState = {
  name: "",
  phone: "",
  device: "",
  service: services[0].name,
  issue: "",
  date: "",
};

export default function RepairBookingForm() {
  const [form, setForm] = useState(initialState);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    // Hook this up to a booking API / calendar integration when ready.
    const context = `a repair booking — Device: ${form.device}, Service: ${form.service}, Preferred date: ${form.date || "any"}, Issue: ${form.issue}`;
    window.open(buildWhatsAppLink(context), "_blank", "noopener,noreferrer");
    setSubmitted(true);
    setForm(initialState);
  };

  return (
    <form id="booking" onSubmit={handleSubmit} className="card scroll-mt-24 p-7 sm:p-8">
      <span className="eyebrow">Book a Repair</span>
      <h2 className="mt-3 font-display text-2xl font-bold sm:text-3xl">Schedule your device drop-off</h2>
      <p className="mt-2 text-sm text-ink-500">
        Tell us what&apos;s wrong and we&apos;ll confirm your booking on WhatsApp within minutes.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="rb-name" className="mb-1.5 block text-sm font-semibold">Full name</label>
          <input id="rb-name" name="name" required value={form.name} onChange={handleChange}
            className="w-full rounded-full border border-royal-100 bg-white px-4 py-2.5 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700" />
        </div>
        <div>
          <label htmlFor="rb-phone" className="mb-1.5 block text-sm font-semibold">Phone number</label>
          <input id="rb-phone" name="phone" type="tel" required value={form.phone} onChange={handleChange}
            className="w-full rounded-full border border-royal-100 bg-white px-4 py-2.5 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700" />
        </div>
        <div>
          <label htmlFor="rb-device" className="mb-1.5 block text-sm font-semibold">Device (brand &amp; model)</label>
          <input id="rb-device" name="device" required placeholder="e.g. iPhone 12, Galaxy A14"
            value={form.device} onChange={handleChange}
            className="w-full rounded-full border border-royal-100 bg-white px-4 py-2.5 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700" />
        </div>
        <div>
          <label htmlFor="rb-service" className="mb-1.5 block text-sm font-semibold">Service needed</label>
          <select id="rb-service" name="service" value={form.service} onChange={handleChange}
            className="w-full rounded-full border border-royal-100 bg-white px-4 py-2.5 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700">
            {services.map((s) => (
              <option key={s.slug} value={s.name}>{s.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="rb-date" className="mb-1.5 block text-sm font-semibold">Preferred date</label>
          <input id="rb-date" name="date" type="date" value={form.date} onChange={handleChange}
            className="w-full rounded-full border border-royal-100 bg-white px-4 py-2.5 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700" />
        </div>
      </div>

      <div className="mt-4">
        <label htmlFor="rb-issue" className="mb-1.5 block text-sm font-semibold">Describe the issue</label>
        <textarea id="rb-issue" name="issue" rows={4} required value={form.issue} onChange={handleChange}
          className="w-full rounded-2xl border border-royal-100 bg-white px-4 py-3 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700" />
      </div>

      <button type="submit" className="btn-primary mt-6 w-full sm:w-fit">
        Confirm Booking
      </button>

      {submitted && (
        <p className="mt-3 text-sm text-royal-600 dark:text-royal-300" role="status">
          Booking details ready — confirm the message on WhatsApp to lock in your slot.
        </p>
      )}
    </form>
  );
}
