import SectionHeading from "@/components/SectionHeading";
import Reveal from "@/components/Reveal";
import { IconShield, IconAward, IconTag, IconBolt, IconStar, IconHeadset } from "@/components/Icons";

const points = [
  { icon: IconShield, title: "Genuine Products", text: "100% authentic parts and accessories — no imitations, ever." },
  { icon: IconAward, title: "Certified Technicians", text: "Every repair handled by trained, experienced professionals." },
  { icon: IconTag, title: "Affordable Prices", text: "Transparent, competitive pricing with no hidden charges." },
  { icon: IconBolt, title: "Fast Repairs", text: "Most repairs completed same-day, often within the hour." },
  { icon: IconStar, title: "Warranty on Selected Repairs", text: "Peace of mind backed by our workmanship guarantee." },
  { icon: IconHeadset, title: "Excellent Customer Service", text: "Friendly support before, during and after every visit." },
];

export default function WhyChooseUs() {
  return (
    <section className="section-y bg-mist dark:bg-ink-900/60">
      <div className="container-page">
        <SectionHeading
          eyebrow="Why OMBStores"
          title="Built on trust, backed by expertise"
          description="From genuine parts to friendly service, here's what sets us apart in Kasoa."
          center
        />
        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {points.map((p, i) => (
            <Reveal key={p.title} delay={i * 60} className="h-full">
              <div className="card flex h-full items-start gap-4 p-6">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-royal-600 text-white">
                  <p.icon className="h-5 w-5" />
                </span>
                <div>
                  <h3 className="font-display text-base font-bold">{p.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-ink-500">{p.text}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
