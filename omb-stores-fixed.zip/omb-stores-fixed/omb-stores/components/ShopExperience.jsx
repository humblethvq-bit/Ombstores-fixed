"use client";

import { useMemo, useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { products, categories } from "@/data/products";
import { useWishlist } from "@/context/WishlistContext";
import ProductCard from "@/components/ProductCard";
import Reveal from "@/components/Reveal";
import { IconSearch } from "@/components/Icons";

const sortOptions = [
  { value: "featured", label: "Featured" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "rating", label: "Top Rated" },
];

export default function ShopExperience() {
  const searchParams = useSearchParams();
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("featured");
  const [wishlistOnly, setWishlistOnly] = useState(false);
  const { items: wishlistItems, isWishlisted } = useWishlist();

  useEffect(() => {
    const search = searchParams.get("search");
    if (search) setQuery(search);
    if (searchParams.get("wishlist") === "1") setWishlistOnly(true);
  }, [searchParams]);

  const filtered = useMemo(() => {
    let list = [...products];

    if (category !== "All") list = list.filter((p) => p.category === category);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (p) => p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)
      );
    }
    if (wishlistOnly) list = list.filter((p) => isWishlisted(p.id));

    switch (sort) {
      case "price-asc":
        list.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        list.sort((a, b) => b.rating - a.rating);
        break;
      default:
        break;
    }

    return list;
  }, [category, query, sort, wishlistOnly, isWishlisted, wishlistItems]);

  return (
    <div>
      {/* Controls */}
      <div className="mb-8 flex flex-col gap-4">
        <div className="relative max-w-md">
          <IconSearch className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-ink-500" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search this catalogue…"
            aria-label="Search products"
            className="w-full rounded-full border border-royal-100 bg-white py-2.5 pl-10 pr-4 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700"
          />
        </div>

        <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
          {categories.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCategory(c)}
              className={`shrink-0 rounded-full border px-4 py-2 text-xs font-semibold transition-colors ${
                category === c
                  ? "border-royal-600 bg-royal-600 text-white"
                  : "border-royal-100 text-ink-700 hover:border-royal-300 dark:border-white/10 dark:text-white/80"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <label className="flex items-center gap-2 text-sm font-semibold text-ink-700 dark:text-white/80">
            <input
              type="checkbox"
              checked={wishlistOnly}
              onChange={(e) => setWishlistOnly(e.target.checked)}
              className="h-4 w-4 rounded border-royal-200 text-royal-600 focus:ring-royal-400"
            />
            Wishlist only
          </label>

          <div className="flex items-center gap-2">
            <label htmlFor="sort" className="text-sm text-ink-500">Sort by</label>
            <select
              id="sort"
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="rounded-full border border-royal-100 bg-white px-3 py-2 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700"
            >
              {sortOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <p className="mb-4 text-sm text-ink-500">{filtered.length} product{filtered.length !== 1 ? "s" : ""} found</p>

      {filtered.length === 0 ? (
        <div className="card p-10 text-center">
          <p className="font-display text-lg font-bold">No products match your filters</p>
          <p className="mt-2 text-sm text-ink-500">Try a different category or clear your search.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {filtered.map((product, i) => (
            <Reveal key={product.id} delay={(i % 5) * 60} className="h-full">
              <ProductCard product={product} />
            </Reveal>
          ))}
        </div>
      )}
    </div>
  );
}
