import Link from "next/link";
import Image from "next/image";
import { buildWhatsAppLink } from "@/data/siteConfig";
import { IconWhatsApp, IconShield, IconBolt, IconStar } from "@/components/Icons";
import Reveal from "@/components/Reveal";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-ink-900 bg-grid-pattern">
      {/* Ambient background glow */}
      <div className="pointer-events-none absolute -left-40 -top-40 h-[28rem] w-[28rem] rounded-full bg-royal-500/25 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -right-32 h-[28rem] w-[28rem] rounded-full bg-royal-400/15 blur-3xl" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(255,255,255,0.06),_transparent_55%)]" />

      <div className="container-page relative grid gap-14 py-28 pt-36 lg:grid-cols-2 lg:items-center lg:py-32 lg:pt-40">
        <Reveal className="text-center lg:text-left">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-widest text-royal-100">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-royal-400" />
            Kasoa Danchira · Mataheko Junction
          </span>
          <h1 className="mt-6 font-display text-4xl font-bold leading-[1.06] text-white sm:text-5xl lg:text-[3.6rem]">
            Your Trusted <span className="text-gradient">Phone &amp; Accessories</span> Store
          </h1>
          <p className="mx-auto mt-6 max-w-lg text-base leading-relaxed text-royal-100/85 sm:text-lg lg:mx-0">
            Professional phone repairs, genuine accessories, smartphones, tablets, and laptops
            at affordable prices.
          </p>

          <div className="mt-9 flex flex-col items-center gap-3 sm:flex-row sm:justify-center lg:justify-start">
            <Link
              href="/shop"
              className="btn-primary w-full !bg-white !text-royal-700 !shadow-[0_8px_24px_-6px_rgba(255,255,255,0.35)] hover:!bg-royal-50 sm:w-auto"
            >
              Shop Now
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.2">
                <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </Link>
            <Link
              href="/repair-services#booking"
              className="btn-secondary w-full border-white/50 bg-white/5 text-white backdrop-blur hover:bg-white hover:text-royal-700 sm:w-auto"
            >
              Book a Repair
            </Link>
            <a href={buildWhatsAppLink()} target="_blank" rel="noopener noreferrer" className="btn-whatsapp w-full sm:w-auto">
              <IconWhatsApp className="h-4 w-4" />
              Chat on WhatsApp
            </a>
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 lg:justify-start">
            <div className="flex items-center gap-2 text-sm text-royal-100/90">
              <IconShield className="h-4.5 w-4.5 text-royal-300" />
              Warranty on Selected Repairs
            </div>
            <div className="flex items-center gap-2 text-sm text-royal-100/90">
              <IconBolt className="h-4.5 w-4.5 text-royal-300" />
              Most Repairs Done Same Day
            </div>
          </div>
        </Reveal>

        {/* Signature element: floating device + glass stat cards */}
        <Reveal delay={120} className="relative mx-auto flex h-80 w-80 items-center justify-center sm:h-96 sm:w-96 lg:mx-0 lg:ml-auto">
          <span className="absolute h-56 w-56 animate-pulseRing rounded-full bg-white/20 reduce-motion-safe sm:h-72 sm:w-72" />
          <span className="absolute h-56 w-56 animate-pulseRing rounded-full bg-white/10 [animation-delay:1.2s] reduce-motion-safe sm:h-72 sm:w-72" />

          <div className="relative animate-float reduce-motion-safe">
            <div className="relative flex h-64 w-32 flex-col items-center justify-between rounded-[2rem] border-4 border-white/25 bg-gradient-to-b from-royal-600 via-royal-800 to-ink-900 p-3 shadow-glow sm:h-80 sm:w-40 sm:p-4">
              <div className="h-1.5 w-10 rounded-full bg-white/25" />
              <div className="flex h-full w-full flex-col items-center justify-center gap-3 rounded-2xl bg-white/[.04]">
                <div className="relative h-12 w-12 sm:h-14 sm:w-14">
                  <Image src="/images/logo/omb-icon-white.png" alt="OMB logo" fill sizes="56px" className="object-contain" />
                </div>
                <span className="text-[10px] font-semibold uppercase tracking-widest text-white/50">Certified Repair</span>
              </div>
              <div className="h-1 w-6 rounded-full bg-white/25" />
            </div>
          </div>

          {/* Floating glass stat card — rating */}
          <div className="glass-card animate-floatSlow reduce-motion-safe absolute -left-4 top-4 hidden items-center gap-3 rounded-2xl px-4 py-3 shadow-xl sm:-left-6 sm:flex">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-amber-400/90 text-ink-900">
              <IconStar className="h-4.5 w-4.5" />
            </span>
            <div>
              <p className="text-sm font-bold leading-none text-white">4.9/5.0</p>
              <p className="text-[11px] text-white/60">Customer Rating</p>
            </div>
          </div>

          {/* Floating glass stat card — repairs completed */}
          <div
            className="glass-card animate-floatSlow reduce-motion-safe absolute -right-2 bottom-8 hidden items-center gap-3 rounded-2xl px-4 py-3 shadow-xl sm:-right-4 sm:flex"
            style={{ animationDelay: "1.4s" }}
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-royal-500 text-white">
              <IconShield className="h-4.5 w-4.5" />
            </span>
            <div>
              <p className="text-sm font-bold leading-none text-white">5,000+</p>
              <p className="text-[11px] text-white/60">Repairs Completed</p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
