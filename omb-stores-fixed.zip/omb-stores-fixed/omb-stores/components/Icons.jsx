// Minimal, dependency-free SVG icon set used across the site.
// Keeping icons inline avoids adding an extra npm package just for a handful of glyphs.

const base = "w-6 h-6";

export function IconScreen(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><rect x="6" y="2" width="12" height="20" rx="2" /><path d="M9 18h6" /></svg>); }
export function IconBattery(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><rect x="2" y="7" width="18" height="10" rx="2" /><path d="M22 10v4" /><path d="M6 10v4" strokeLinecap="round" /></svg>); }
export function IconPort(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><rect x="7" y="3" width="10" height="18" rx="2" /><path d="M10 21v1M14 21v1" /></svg>); }
export function IconCamera(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><rect x="3" y="7" width="18" height="13" rx="2" /><circle cx="12" cy="13.5" r="3.5" /><path d="M9 7l1.5-3h3L15 7" /></svg>); }
export function IconSpeaker(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><rect x="5" y="2" width="14" height="20" rx="2" /><circle cx="12" cy="15" r="3" /><circle cx="12" cy="6" r="1" /></svg>); }
export function IconFaceId(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M4 8V6a2 2 0 012-2h2M4 16v2a2 2 0 002 2h2M20 8V6a2 2 0 00-2-2h-2M20 16v2a2 2 0 01-2 2h-2" strokeLinecap="round" /><circle cx="9" cy="11" r="0.8" fill="currentColor" /><circle cx="15" cy="11" r="0.8" fill="currentColor" /><path d="M9 15c1 1 5 1 6 0" strokeLinecap="round" /></svg>); }
export function IconSoftware(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M12 3v4M12 17v4M3 12h4M17 12h4" strokeLinecap="round" /><circle cx="12" cy="12" r="4" /></svg>); }
export function IconUnlock(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><rect x="4" y="11" width="16" height="9" rx="2" /><path d="M8 11V8a4 4 0 017.5-2" strokeLinecap="round" /></svg>); }
export function IconRecovery(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M3 12a9 9 0 1 0 3-6.7" strokeLinecap="round" /><path d="M3 4v5h5" strokeLinecap="round" strokeLinejoin="round" /></svg>); }
export function IconLaptop(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><rect x="4" y="4" width="16" height="11" rx="1.5" /><path d="M2 19h20" strokeLinecap="round" /></svg>); }

export function IconSearch(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={base} {...props}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" strokeLinecap="round" /></svg>); }
export function IconCart(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><circle cx="9" cy="20" r="1.4" /><circle cx="18" cy="20" r="1.4" /><path d="M2 3h2l2.4 12.2a2 2 0 002 1.8h9.2a2 2 0 002-1.6L21 8H6" strokeLinecap="round" strokeLinejoin="round" /></svg>); }
export function IconHeart(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M12 21s-7.5-4.6-10-9.3C.4 8 2 4.5 5.5 4a5 5 0 016.5 2 5 5 0 016.5-2C22 4.5 23.6 8 22 11.7 19.5 16.4 12 21 12 21z" /></svg>); }
export function IconSun(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><circle cx="12" cy="12" r="4.5" /><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4" strokeLinecap="round" /></svg>); }
export function IconMoon(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z" strokeLinejoin="round" /></svg>); }
export function IconMenu(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={base} {...props}><path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round" /></svg>); }
export function IconClose(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={base} {...props}><path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" /></svg>); }
export function IconChevronDown(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={base} {...props}><path d="M6 9l6 6 6-6" strokeLinecap="round" strokeLinejoin="round" /></svg>); }
export function IconStar(props) { return (<svg viewBox="0 0 24 24" fill="currentColor" className={base} {...props}><path d="M12 2.5l2.9 6.1 6.7.8-4.9 4.6 1.3 6.6L12 17.6 5.9 20.6l1.3-6.6-4.9-4.6 6.7-.8L12 2.5z" /></svg>); }
export function IconWhatsApp(props) { return (<svg viewBox="0 0 24 24" fill="currentColor" className={base} {...props}><path d="M12 2a10 10 0 00-8.6 15L2 22l5.2-1.4A10 10 0 1012 2zm0 18a8 8 0 01-4.1-1.1l-.3-.2-3.1.8.8-3-.2-.3A8 8 0 1112 20zm4.4-6c-.2-.1-1.4-.7-1.6-.8-.2-.1-.4-.1-.6.1-.2.2-.6.8-.8 1-.1.2-.3.2-.5.1-.2-.1-1-.4-2-1.2-.7-.7-1.2-1.5-1.4-1.7-.1-.2 0-.4.1-.5l.4-.5c.1-.1.2-.3.2-.4.1-.2 0-.3 0-.4l-.7-1.7c-.2-.4-.4-.4-.6-.4h-.5c-.2 0-.4.1-.6.3-.2.2-.8.8-.8 1.9 0 1.1.8 2.2.9 2.4.1.2 1.6 2.5 4 3.5.5.2 1 .4 1.3.5.5.2 1 .1 1.4.1.4-.1 1.4-.6 1.6-1.1.2-.5.2-1 .1-1.1-.1-.1-.2-.2-.4-.3z" /></svg>); }
export function IconPin(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M12 21s7-6.5 7-11.5A7 7 0 105 9.5C5 14.5 12 21 12 21z" /><circle cx="12" cy="9.5" r="2.3" /></svg>); }
export function IconPhoneCall(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M4 5c0 8.3 6.7 15 15 15l3-3-4.5-3-2 2A11.5 11.5 0 019 10.5l2-2-3-4.5L4 7z" strokeLinejoin="round" /></svg>); }
export function IconMail(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 7l9 6 9-6" /></svg>); }
export function IconClock(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.5 2" strokeLinecap="round" /></svg>); }
export function IconShield(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M12 3l7 3v5c0 5-3.4 8.4-7 10-3.6-1.6-7-5-7-10V6l7-3z" strokeLinejoin="round" /><path d="M9 12l2 2 4-4" strokeLinecap="round" strokeLinejoin="round" /></svg>); }
export function IconTag(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M20 13L13 20 4 11V4h7l9 9z" strokeLinejoin="round" /><circle cx="8" cy="8" r="1.3" fill="currentColor" /></svg>); }
export function IconBolt(props) { return (<svg viewBox="0 0 24 24" fill="currentColor" className={base} {...props}><path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z" /></svg>); }
export function IconAward(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><circle cx="12" cy="8" r="5" /><path d="M8.5 12.5L7 21l5-2.5L17 21l-1.5-8.5" strokeLinejoin="round" /></svg>); }
export function IconHeadset(props) { return (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={base} {...props}><path d="M4 13v-1a8 8 0 0116 0v1" strokeLinecap="round" /><rect x="2.5" y="13" width="4" height="6" rx="1.5" /><rect x="17.5" y="13" width="4" height="6" rx="1.5" /></svg>); }

const serviceIconMap = {
  screen: IconScreen,
  battery: IconBattery,
  port: IconPort,
  camera: IconCamera,
  speaker: IconSpeaker,
  faceid: IconFaceId,
  software: IconSoftware,
  unlock: IconUnlock,
  recovery: IconRecovery,
  laptop: IconLaptop,
};

export function ServiceIcon({ name, className }) {
  const Cmp = serviceIconMap[name] || IconScreen;
  return <Cmp className={className || base} />;
}
