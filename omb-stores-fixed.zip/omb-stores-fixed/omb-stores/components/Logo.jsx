import Link from "next/link";
import Image from "next/image";

/**
 * Renders the official OMB icon mark exactly as supplied — no redesign.
 * `on` controls which pre-exported version of the mark is used:
 *  - "light": full-color mark (blue/black on transparent) for light or transparent surfaces
 *  - "dark":  white mark on transparent, for dark surfaces (hero, footer, loading screen)
 */
export default function Logo({ className = "", on = "light", showWordmark = true, size = 40 }) {
  const src =
    on === "dark"
      ? "/images/logo/omb-icon-white.png"
      : "/images/logo/omb-icon-color.png";

  return (
    <Link href="/" className={`flex items-center gap-2.5 ${className}`} aria-label="OMBStores home">
      <span className="relative shrink-0" style={{ width: size, height: size }}>
        <Image
          src={src}
          alt="OMB Phone & Accessories logo"
          fill
          sizes={`${size}px`}
          className="object-contain"
          priority
        />
      </span>
      {showWordmark && (
        <span
          className={`font-display text-lg font-bold leading-none tracking-tight ${
            on === "dark" ? "text-white" : "text-ink-900 dark:text-white"
          }`}
        >
          OMB<span className={on === "dark" ? "text-royal-200" : "text-royal-600 dark:text-royal-300"}>Stores</span>
        </span>
      )}
    </Link>
  );
}
