"use client";

import { useState } from "react";

export default function NewsletterCTA() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email) return;
    // Wire this up to your email provider (Mailchimp, Resend, etc.) when ready.
    setStatus("success");
    setEmail("");
  };

  return (
    <section className="px-5 py-16 sm:px-6 sm:py-20 lg:px-8">
      <div className="relative mx-auto max-w-6xl overflow-hidden rounded-[2rem] bg-gradient-to-br from-royal-600 via-royal-700 to-ink-900 px-8 py-14 sm:px-14">
        <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div className="relative flex flex-col items-center justify-between gap-8 text-center lg:flex-row lg:text-left">
          <div>
            <h2 className="font-display text-2xl font-bold text-white sm:text-3xl">
              Get repair tips &amp; deals in your inbox
            </h2>
            <p className="mt-2 text-sm text-royal-100/85 sm:text-base">
              No spam — just useful updates from OMBStores.
            </p>
          </div>
          <form onSubmit={handleSubmit} className="flex w-full max-w-md flex-col gap-3 sm:flex-row">
            <label htmlFor="cta-email" className="sr-only">Email address</label>
            <input
              id="cta-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-full border border-white/25 bg-white/10 px-5 py-3 text-sm text-white placeholder:text-white/50 focus:border-white/50 focus:outline-none"
            />
            <button
              type="submit"
              className="shrink-0 rounded-full bg-white px-6 py-3 text-sm font-semibold text-royal-700 transition-colors hover:bg-royal-50"
            >
              Subscribe
            </button>
          </form>
        </div>
        {status === "success" && (
          <p className="relative mt-4 text-center text-sm text-royal-100 lg:text-left" role="status">
            Thanks for subscribing! Watch your inbox.
          </p>
        )}
      </div>
    </section>
  );
}
