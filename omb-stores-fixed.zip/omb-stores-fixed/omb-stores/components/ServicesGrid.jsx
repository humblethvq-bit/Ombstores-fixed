import { services } from "@/data/services";
import ServiceCard from "@/components/ServiceCard";
import Reveal from "@/components/Reveal";

export default function ServicesGrid({ limit }) {
  const list = limit ? services.slice(0, limit) : services;
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
      {list.map((service, i) => (
        <Reveal key={service.slug} delay={i * 60} className="h-full">
          <ServiceCard service={service} />
        </Reveal>
      ))}
    </div>
  );
}
