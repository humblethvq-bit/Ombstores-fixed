import { siteConfig, buildWhatsAppLink } from "@/data/siteConfig";
import { IconPin, IconPhoneCall, IconMail, IconClock, IconWhatsApp } from "@/components/Icons";

export default function ContactSection({ showForm = false }) {
  return (
    <section className="section-y bg-mist dark:bg-ink-900/60">
      <div className="container-page grid gap-8 lg:grid-cols-2">
        <div className="overflow-hidden rounded-3xl border border-royal-100 shadow-card dark:border-white/10">
          <iframe
            title="OMBStores location — Kasoa Danchira, Mataheko Junction"
            src={siteConfig.location.mapEmbedUrl}
            className="h-80 w-full lg:h-full lg:min-h-[420px]"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>

        <div className="card flex flex-col gap-6 p-7 sm:p-8">
          <div>
            <span className="eyebrow">Visit or Reach Us</span>
            <h2 className="mt-3 font-display text-2xl font-bold sm:text-3xl">Get in touch</h2>
          </div>

          <ul className="flex flex-col gap-5">
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-royal-50 text-royal-600 dark:bg-white/5 dark:text-royal-300">
                <IconPin className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm font-bold">Location</p>
                <p className="text-sm text-ink-500">{siteConfig.location.line1}, {siteConfig.location.line2}, {siteConfig.location.city}</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-royal-50 text-royal-600 dark:bg-white/5 dark:text-royal-300">
                <IconPhoneCall className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm font-bold">Phone</p>
                <a href={`tel:${siteConfig.phone.tel}`} className="text-sm text-ink-500 hover:text-royal-600">
                  {siteConfig.phone.display}
                </a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-royal-50 text-royal-600 dark:bg-white/5 dark:text-royal-300">
                <IconMail className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm font-bold">Email</p>
                <a href={`mailto:${siteConfig.email}`} className="text-sm text-ink-500 hover:text-royal-600">
                  {siteConfig.email}
                </a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-royal-50 text-royal-600 dark:bg-white/5 dark:text-royal-300">
                <IconClock className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm font-bold">Business Hours</p>
                <ul className="text-sm text-ink-500">
                  {siteConfig.hours.map((h) => (
                    <li key={h.day}>{h.day}: {h.time}</li>
                  ))}
                </ul>
              </div>
            </li>
          </ul>

          <a href={buildWhatsAppLink()} target="_blank" rel="noopener noreferrer" className="btn-whatsapp w-full">
            <IconWhatsApp className="h-4 w-4" />
            Chat on WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
