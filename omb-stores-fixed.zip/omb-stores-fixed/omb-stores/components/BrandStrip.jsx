import { brands } from "@/data/brands";

export default function BrandStrip() {
  const doubled = [...brands, ...brands];
  return (
    <div className="overflow-hidden border-y border-royal-100 bg-white py-8 dark:border-white/10 dark:bg-ink-900">
      <div className="container-page mb-5">
        <p className="text-center text-xs font-semibold uppercase tracking-[0.2em] text-ink-500">
          Genuine products from the brands you trust
        </p>
      </div>
      <div className="no-scrollbar flex w-max animate-marquee gap-12 px-6 reduce-motion-safe">
        {doubled.map((brand, i) => (
          <div
            key={`${brand.name}-${i}`}
            className="flex items-center gap-2.5 text-ink-500 grayscale transition-all hover:text-royal-600 hover:grayscale-0 dark:text-white/50"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-full border border-current text-sm font-bold">
              {brand.initial}
            </span>
            <span className="font-display text-lg font-semibold whitespace-nowrap">{brand.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
