const stats = [
  { value: "5,000+", label: "Repairs Completed" },
  { value: "4.9★", label: "Average Rating" },
  { value: "8", label: "Brands Carried" },
  { value: "30 min", label: "Avg. Repair Time" },
];

export default function StatsBand() {
  return (
    <section className="bg-royal-600 py-12">
      <div className="container-page grid grid-cols-2 gap-8 text-center text-white sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label}>
            <p className="font-display text-3xl font-extrabold sm:text-4xl">{s.value}</p>
            <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-royal-100/90 sm:text-sm">
              {s.label}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
