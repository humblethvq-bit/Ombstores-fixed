"use client";

import { useState } from "react";

export default function Newsletter({ variant = "light" }) {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle"); // idle | success

  const dark = variant === "dark";

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email) return;
    // Wire this up to your email provider (Mailchimp, Resend, etc.) when ready.
    setStatus("success");
    setEmail("");
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2.5">
      <label htmlFor="newsletter-email" className={`text-sm ${dark ? "text-white/70" : "text-ink-500"}`}>
        Get repair tips &amp; deals in your inbox.
      </label>
      <div className="flex gap-2">
        <input
          id="newsletter-email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className={`w-full rounded-full border px-4 py-2.5 text-sm focus:outline-none ${
            dark
              ? "border-white/20 bg-white/10 text-white placeholder:text-white/50 focus:border-white/40"
              : "border-royal-100 bg-white text-ink-900 placeholder:text-ink-500 focus:border-royal-400"
          }`}
        />
        <button
          type="submit"
          className={`shrink-0 rounded-full px-5 py-2.5 text-sm font-semibold transition-colors ${
            dark ? "bg-white text-royal-700 hover:bg-white/90" : "bg-royal-600 text-white hover:bg-royal-700"
          }`}
        >
          Join
        </button>
      </div>
      {status === "success" && (
        <p className={`text-xs ${dark ? "text-white/70" : "text-royal-600"}`} role="status">
          Thanks for subscribing! Watch your inbox.
        </p>
      )}
    </form>
  );
}
