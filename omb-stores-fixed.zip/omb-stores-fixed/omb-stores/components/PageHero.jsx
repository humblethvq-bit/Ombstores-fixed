export default function PageHero({ eyebrow, title, description }) {
  return (
    <section className="relative overflow-hidden bg-ink-900 bg-grid-pattern">
      <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-royal-500/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-royal-400/20 blur-3xl" />
      <div className="container-page relative py-16 text-center sm:py-20">
        {eyebrow && (
          <span className="eyebrow inline-flex rounded-full bg-white/10 px-4 py-1.5 text-royal-100">{eyebrow}</span>
        )}
        <h1 className="mx-auto mt-5 max-w-2xl font-display text-3xl font-bold text-white sm:text-5xl">{title}</h1>
        {description && (
          <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-royal-100/90">{description}</p>
        )}
      </div>
    </section>
  );
}
