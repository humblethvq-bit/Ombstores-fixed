"use client";

import { useState } from "react";
import { buildWhatsAppLink } from "@/data/siteConfig";

const initialState = { name: "", phone: "", subject: "", message: "" };

export default function ContactForm() {
  const [form, setForm] = useState(initialState);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    // Hook this up to your form backend (e.g. an API route + email service) when ready.
    setSubmitted(true);
    const context = `general enquiry — ${form.subject || "message"}: ${form.message}`;
    window.open(buildWhatsAppLink(context), "_blank", "noopener,noreferrer");
    setForm(initialState);
  };

  return (
    <form onSubmit={handleSubmit} className="card flex flex-col gap-4 p-7 sm:p-8">
      <div>
        <span className="eyebrow">Send a Message</span>
        <h2 className="mt-3 font-display text-2xl font-bold sm:text-3xl">We&apos;d love to hear from you</h2>
        <p className="mt-2 text-sm text-ink-500">
          Fill in the form and we&apos;ll follow up on WhatsApp, or reach us directly using the contact details.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Full name" name="name" value={form.name} onChange={handleChange} required />
        <Field label="Phone number" name="phone" value={form.phone} onChange={handleChange} required type="tel" />
      </div>
      <Field label="Subject" name="subject" value={form.subject} onChange={handleChange} />
      <div>
        <label htmlFor="message" className="mb-1.5 block text-sm font-semibold">Message</label>
        <textarea
          id="message"
          name="message"
          rows={4}
          required
          value={form.message}
          onChange={handleChange}
          className="w-full rounded-2xl border border-royal-100 bg-white px-4 py-3 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700"
        />
      </div>

      <button type="submit" className="btn-primary mt-1 w-full sm:w-fit">
        Send Message
      </button>

      {submitted && (
        <p className="text-sm text-royal-600 dark:text-royal-300" role="status">
          Thanks! We&apos;ve opened WhatsApp so you can send your message directly.
        </p>
      )}
    </form>
  );
}

function Field({ label, name, value, onChange, required, type = "text" }) {
  return (
    <div>
      <label htmlFor={name} className="mb-1.5 block text-sm font-semibold">{label}</label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        value={value}
        onChange={onChange}
        className="w-full rounded-full border border-royal-100 bg-white px-4 py-2.5 text-sm focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700"
      />
    </div>
  );
}
