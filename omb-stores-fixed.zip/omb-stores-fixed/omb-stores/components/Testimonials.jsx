import SectionHeading from "@/components/SectionHeading";
import Reveal from "@/components/Reveal";
import { testimonials } from "@/data/testimonials";
import { IconStar } from "@/components/Icons";

function initials(name) {
  const parts = name.trim().split(" ");
  return `${parts[0]?.[0] ?? ""}${parts[1]?.[0] ?? ""}`.toUpperCase();
}

export default function Testimonials() {
  return (
    <section className="section-y">
      <div className="container-page">
        <SectionHeading
          eyebrow="Customer Love"
          title="Trusted by customers across Kasoa"
          description="Real feedback from people we've helped get back online."
          center
        />
        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 80} className="h-full">
              <figure className="card flex h-full flex-col gap-4 p-6">
                <div className="flex items-center justify-between">
                  <div className="flex gap-0.5 text-amber-400">
                    {Array.from({ length: 5 }).map((_, j) => (
                      <IconStar key={j} className={`h-4 w-4 ${j < t.rating ? "opacity-100" : "opacity-20"}`} />
                    ))}
                  </div>
                  <svg viewBox="0 0 24 24" className="h-6 w-6 text-royal-100 dark:text-white/10" fill="currentColor">
                    <path d="M7 7c-2.8 0-5 2.2-5 5v5h5v-5H4.5C4.7 9.9 5.7 9 7 9V7zm10 0c-2.8 0-5 2.2-5 5v5h5v-5h-2.5c.2-2.1 1.2-3 2.5-3V7z" />
                  </svg>
                </div>
                <blockquote className="flex-1 text-sm leading-relaxed text-ink-700 dark:text-white/80">
                  “{t.quote}”
                </blockquote>
                <figcaption className="flex items-center gap-3 border-t border-royal-100 pt-4 dark:border-white/10">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-royal-600 text-xs font-bold text-white">
                    {initials(t.name)}
                  </span>
                  <div>
                    <p className="text-sm font-bold leading-none">{t.name}</p>
                    <p className="mt-0.5 text-xs text-ink-500">{t.location}</p>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
