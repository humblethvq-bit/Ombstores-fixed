import Link from "next/link";
import { ServiceIcon } from "@/components/Icons";

export default function ServiceCard({ service }) {
  return (
    <Link
      href={`/repair-services#${service.slug}`}
      className="card group flex h-full flex-col gap-4 p-6"
    >
      <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-royal-50 text-royal-600 transition-colors group-hover:bg-royal-600 group-hover:text-white dark:bg-white/5 dark:text-royal-300">
        <ServiceIcon name={service.icon} />
      </span>
      <div>
        <h3 className="font-display text-base font-bold">{service.name}</h3>
        <p className="mt-1.5 text-sm leading-relaxed text-ink-500">{service.summary}</p>
      </div>
      <div className="mt-auto flex items-center justify-between border-t border-royal-100 pt-4 text-xs font-semibold text-ink-500 dark:border-white/10">
        <span>{service.turnaround}</span>
        <span className="text-royal-600 dark:text-royal-300">From {service.priceFrom}</span>
      </div>
    </Link>
  );
}
