"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { IconSearch } from "@/components/Icons";

export default function SearchBar({ className = "", compact = false }) {
  const [query, setQuery] = useState("");
  const router = useRouter();

  const handleSubmit = (e) => {
    e.preventDefault();
    router.push(query.trim() ? `/shop?search=${encodeURIComponent(query.trim())}` : "/shop");
  };

  return (
    <form onSubmit={handleSubmit} role="search" className={`relative ${className}`}>
      <label htmlFor="site-search" className="sr-only">
        Search products
      </label>
      <IconSearch className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-ink-500" />
      <input
        id="site-search"
        type="search"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search phones, cases, chargers…"
        className={`w-full rounded-full border border-royal-100 bg-white py-2.5 pl-10 pr-4 text-sm text-ink-900 placeholder:text-ink-500 focus:border-royal-400 focus:outline-none dark:border-white/10 dark:bg-ink-700 dark:text-white ${
          compact ? "py-2" : "py-2.5"
        }`}
      />
    </form>
  );
}
