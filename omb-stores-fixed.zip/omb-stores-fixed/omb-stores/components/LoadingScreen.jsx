"use client";

import { useEffect, useState } from "react";
import Image from "next/image";

export default function LoadingScreen() {
  const [hidden, setHidden] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Brief branded pause on first load only — long enough to register as
    // intentional, short enough not to feel like a delay.
    const timer = setTimeout(() => setHidden(true), 900);
    return () => clearTimeout(timer);
  }, []);

  if (!mounted) return null;

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center gap-4 bg-ink-900 transition-opacity duration-500 ${
        hidden ? "pointer-events-none opacity-0" : "opacity-100"
      }`}
    >
      <div className="relative">
        <span className="absolute inset-0 -m-4 animate-pulseRing rounded-full bg-royal-500/30 reduce-motion-safe" />
        <div className="relative h-20 w-20 animate-logoPulse reduce-motion-safe">
          <Image
            src="/images/logo/omb-icon-white.png"
            alt="OMBStores"
            fill
            sizes="80px"
            className="object-contain"
            priority
          />
        </div>
      </div>
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-white/50">OMBStores</p>
    </div>
  );
}
