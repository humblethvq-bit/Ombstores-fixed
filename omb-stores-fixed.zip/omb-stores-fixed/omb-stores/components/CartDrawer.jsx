"use client";

import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/context/CartContext";
import { IconClose } from "@/components/Icons";
import { buildWhatsAppLink } from "@/data/siteConfig";

export default function CartDrawer() {
  const { items, isOpen, setIsOpen, removeItem, updateQty, subtotal } = useCart();

  const checkoutMessage = items
    .map((i) => `${i.qty}x ${i.name}`)
    .join(", ");

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={() => setIsOpen(false)}
        aria-hidden="true"
        className={`fixed inset-0 z-[60] bg-ink-900/50 transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />

      {/* Panel */}
      <aside
        role="dialog"
        aria-modal="true"
        aria-label="Shopping cart"
        className={`fixed right-0 top-0 z-[70] flex h-full w-full max-w-md flex-col bg-white shadow-2xl transition-transform duration-300 dark:bg-ink-900 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between border-b border-royal-100 px-5 py-4 dark:border-white/10">
          <h2 className="font-display text-lg font-bold">Your Cart</h2>
          <button
            type="button"
            onClick={() => setIsOpen(false)}
            aria-label="Close cart"
            className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-royal-50 dark:hover:bg-white/5"
          >
            <IconClose className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
              <p className="text-ink-500">Your cart is empty.</p>
              <Link href="/shop" onClick={() => setIsOpen(false)} className="btn-primary">
                Browse Shop
              </Link>
            </div>
          ) : (
            <ul className="flex flex-col gap-4">
              {items.map((item) => (
                <li key={item.id} className="flex gap-3 rounded-2xl border border-royal-100 p-3 dark:border-white/10">
                  <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-mist dark:bg-white/5">
                    <Image src={item.image} alt={item.name} fill sizes="64px" className="object-cover" />
                  </div>
                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm font-semibold leading-tight">{item.name}</p>
                      <button
                        type="button"
                        onClick={() => removeItem(item.id)}
                        aria-label={`Remove ${item.name}`}
                        className="text-ink-500 hover:text-royal-600"
                      >
                        <IconClose className="h-4 w-4" />
                      </button>
                    </div>
                    <p className="text-sm font-bold text-royal-600 dark:text-royal-300">
                      GH₵ {item.price.toLocaleString()}
                    </p>
                    <div className="mt-1 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => updateQty(item.id, item.qty - 1)}
                        className="h-7 w-7 rounded-full border border-royal-100 text-sm font-bold dark:border-white/10"
                        aria-label="Decrease quantity"
                      >
                        −
                      </button>
                      <span className="w-6 text-center text-sm">{item.qty}</span>
                      <button
                        type="button"
                        onClick={() => updateQty(item.id, item.qty + 1)}
                        className="h-7 w-7 rounded-full border border-royal-100 text-sm font-bold dark:border-white/10"
                        aria-label="Increase quantity"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t border-royal-100 px-5 py-4 dark:border-white/10">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-semibold text-ink-500">Subtotal</span>
              <span className="font-display text-lg font-bold">GH₵ {subtotal.toLocaleString()}</span>
            </div>
            <p className="mb-3 text-xs text-ink-500">
              Mobile Money &amp; card checkout coming soon. For now, confirm your order on WhatsApp.
            </p>
            <a
              href={buildWhatsAppLink(`to order: ${checkoutMessage} (Subtotal GH₵ ${subtotal.toLocaleString()})`)}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-whatsapp w-full"
            >
              Checkout on WhatsApp
            </a>
          </div>
        )}
      </aside>
    </>
  );
}
