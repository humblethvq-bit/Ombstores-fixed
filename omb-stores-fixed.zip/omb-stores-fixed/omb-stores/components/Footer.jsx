import Link from "next/link";
import Logo from "@/components/Logo";
import Newsletter from "@/components/Newsletter";
import { siteConfig } from "@/data/siteConfig";
import { IconPin, IconPhoneCall, IconMail, IconClock } from "@/components/Icons";

const shopLinks = [
  { href: "/shop", label: "Smartphones" },
  { href: "/shop", label: "Accessories" },
  { href: "/repair-services", label: "Repair Services" },
  { href: "/about", label: "About Us" },
];

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-ink-900 text-white">
      <div className="container-page section-y !py-14">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_1fr_1fr_1.3fr]">
          <div>
            <Logo on="dark" size={44} />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/70">
              {siteConfig.description}
            </p>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-bold uppercase tracking-wide text-white/90">Shop</h3>
            <ul className="flex flex-col gap-2.5 text-sm text-white/70">
              {shopLinks.map((l) => (
                <li key={l.label}>
                  <Link href={l.href} className="transition-colors hover:text-white">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-bold uppercase tracking-wide text-white/90">Contact</h3>
            <ul className="flex flex-col gap-3 text-sm text-white/70">
              <li className="flex items-start gap-2">
                <IconPin className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{siteConfig.location.line1}, {siteConfig.location.line2}</span>
              </li>
              <li className="flex items-center gap-2">
                <IconPhoneCall className="h-4 w-4 shrink-0" />
                <a href={`tel:${siteConfig.phone.tel}`} className="hover:text-white">{siteConfig.phone.display}</a>
              </li>
              <li className="flex items-center gap-2">
                <IconMail className="h-4 w-4 shrink-0" />
                <a href={`mailto:${siteConfig.email}`} className="hover:text-white">{siteConfig.email}</a>
              </li>
              <li className="flex items-start gap-2">
                <IconClock className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{siteConfig.hours[0].day}: {siteConfig.hours[0].time}</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-bold uppercase tracking-wide text-white/90">Stay Updated</h3>
            <Newsletter variant="dark" />
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-white/50 sm:flex-row">
          <p>&copy; {new Date().getFullYear()} OMBStores. All rights reserved.</p>
          <p>Kasoa Danchira, Mataheko Junction — Ghana</p>
        </div>
      </div>
    </footer>
  );
}
