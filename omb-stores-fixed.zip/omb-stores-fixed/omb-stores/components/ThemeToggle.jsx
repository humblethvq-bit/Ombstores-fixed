"use client";

import { useTheme } from "@/context/ThemeContext";
import { IconSun, IconMoon } from "@/components/Icons";

export default function ThemeToggle({ className = "" }) {
  const { theme, toggleTheme, mounted } = useTheme();

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={mounted && theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
      className={`flex h-10 w-10 items-center justify-center rounded-full border border-royal-100 bg-white text-royal-600 transition-colors hover:bg-royal-50 dark:border-white/10 dark:bg-ink-700 dark:text-royal-200 dark:hover:bg-ink-700/70 ${className}`}
    >
      {mounted && theme === "dark" ? <IconSun className="h-5 w-5" /> : <IconMoon className="h-5 w-5" />}
    </button>
  );
}
