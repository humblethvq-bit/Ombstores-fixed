"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import Logo from "@/components/Logo";
import SearchBar from "@/components/SearchBar";
import ThemeToggle from "@/components/ThemeToggle";
import { IconCart, IconHeart, IconMenu, IconClose } from "@/components/Icons";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";

const links = [
  { href: "/", label: "Home" },
  { href: "/shop", label: "Shop" },
  { href: "/repair-services", label: "Repair Services" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const { count, setIsOpen } = useCart();
  const { count: wishCount } = useWishlist();

  // Every page opens on a dark royal-blue hero, so the nav starts transparent
  // with the white logo mark, then swaps to a blurred white surface + color
  // logo once the page scrolls past the hero.
  const solid = scrolled || open;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 64);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        solid
          ? "border-b border-royal-100 bg-white/90 backdrop-blur-md shadow-sm dark:border-white/10 dark:bg-ink-900/90"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <div className="container-page flex h-16 items-center justify-between gap-4 lg:h-20">
        <Logo on={solid ? "light" : "dark"} />

        <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary">
          {links.map((link) => {
            const active = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`text-sm font-semibold transition-colors ${
                  solid
                    ? active
                      ? "text-royal-600 dark:text-royal-300"
                      : "text-ink-700 hover:text-royal-600 dark:text-white/80 dark:hover:text-royal-300"
                    : active
                    ? "text-white"
                    : "text-white/80 hover:text-white"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className={`hidden w-full max-w-xs md:block lg:max-w-sm ${solid ? "" : "opacity-95"}`}>
          <SearchBar compact />
        </div>

        <div className="flex items-center gap-2">
          <ThemeToggle
            className={`hidden sm:flex ${solid ? "" : "border-white/30 bg-white/10 text-white hover:bg-white/20"}`}
          />

          <Link
            href="/shop?wishlist=1"
            aria-label={`Wishlist, ${wishCount} items`}
            className={`relative hidden h-10 w-10 items-center justify-center rounded-full border transition-colors sm:flex ${
              solid
                ? "border-royal-100 text-ink-700 hover:bg-royal-50 dark:border-white/10 dark:text-white"
                : "border-white/30 bg-white/10 text-white hover:bg-white/20"
            }`}
          >
            <IconHeart className="h-5 w-5" />
            {wishCount > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-royal-600 px-1 text-[10px] font-bold text-white">
                {wishCount}
              </span>
            )}
          </Link>

          <button
            type="button"
            onClick={() => setIsOpen(true)}
            aria-label={`Open cart, ${count} items`}
            className={`relative flex h-10 w-10 items-center justify-center rounded-full border transition-colors ${
              solid
                ? "border-royal-100 text-ink-700 hover:bg-royal-50 dark:border-white/10 dark:text-white"
                : "border-white/30 bg-white/10 text-white hover:bg-white/20"
            }`}
          >
            <IconCart className="h-5 w-5" />
            {count > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-royal-600 px-1 text-[10px] font-bold text-white">
                {count}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            className={`flex h-10 w-10 items-center justify-center rounded-full border transition-colors lg:hidden ${
              solid
                ? "border-royal-100 text-ink-700 dark:border-white/10 dark:text-white"
                : "border-white/30 bg-white/10 text-white"
            }`}
          >
            {open ? <IconClose className="h-5 w-5" /> : <IconMenu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden border-t border-royal-100 bg-white transition-[max-height] duration-300 dark:border-white/10 dark:bg-ink-900 lg:hidden ${
          open ? "max-h-96" : "max-h-0 border-t-0"
        }`}
      >
        <div className="container-page flex flex-col gap-1 py-4">
          <div className="mb-2 md:hidden">
            <SearchBar />
          </div>
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`rounded-xl px-3 py-2.5 text-sm font-semibold ${
                pathname === link.href
                  ? "bg-royal-50 text-royal-600 dark:bg-white/5 dark:text-royal-300"
                  : "text-ink-700 dark:text-white/80"
              }`}
            >
              {link.label}
            </Link>
          ))}
          <div className="mt-2 flex items-center justify-between px-3">
            <span className="text-sm font-semibold text-ink-500">Appearance</span>
            <ThemeToggle />
          </div>
        </div>
      </div>
    </header>
  );
}
